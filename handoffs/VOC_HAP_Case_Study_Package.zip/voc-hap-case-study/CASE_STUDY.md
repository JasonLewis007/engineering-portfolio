# VOC/HAP Reporting Modernization

**Independent engineering of a deployed customer-reporting application**

- **Engineer:** Jason Lewis
- **Role:** Independent software engineer and application owner
- **Status:** Deployed and currently in use, confirmed by Jason
- **Legacy system:** VB.NET application experiencing Crystal Reports runtime issues
- **Previously documented portfolio stack:** .NET 8, WPF, SQL Server, QuestPDF

## Overview

I independently developed the VOC/HAP reporting application as a replacement for a legacy VB.NET application that was experiencing Crystal Reports runtime issues. The replacement is deployed and currently being used.

The interface brings customer reporting configuration, email-recipient management, historical PDF generation, and monthly report/email processing into a coordinated desktop workflow.

## The business and engineering context

Monthly customer reporting involves more than producing a document. Users need to maintain customer assignments, select recipients, review reporting periods, generate reports, and distinguish a historical review from a run that sends customer emails.

The legacy application's Crystal Reports runtime issues provided the modernization context. The available facts do not establish their exact root cause, frequency, downtime, or a particular runtime troubleshooting technique, so this case study does not invent those details.

## Independent ownership

Jason confirmed independent development of the application. The public presentation should emphasize that ownership and the deployed status. Specific design decisions, technical challenges, test methods, deployment procedures, and measured business impacts require concrete supporting detail before being presented as project facts.

## Application workflow

### 1. Reporting dashboard

The dashboard organizes the main reporting tasks and displays reporting-period, last-run, and run-result information. The public image conceals operational dates and counts.

![Redacted reporting dashboard](images/voc-hap-01-dashboard.png)

### 2. Customer management

The customer-management screen supports customer setup and report assignment, with controls for adding and editing customers. The original grid includes customer configuration, recipient counts, consignment settings, and active status; its record content is concealed in the public image.

![Redacted customer-management screen](images/voc-hap-02-customer-management.png)

### 3. Add a customer

The add-customer dialog organizes customer details, configuration settings, and recipient-assignment fields. Identifiers and any background records are concealed.

![Redacted add-customer dialog](images/voc-hap-03-add-customer.png)

### 4. Edit customer reporting setup

The edit-customer dialog brings customer details and assigned email recipients into one form. Entered values and underlying customer records are concealed.

![Redacted edit-customer dialog](images/voc-hap-04-edit-customer.png)

### 5. Recipient management

The recipient-management screen provides controls to add and edit recipients. Names, email addresses, and record identifiers are concealed in the public image.

![Redacted recipient-management screen](images/voc-hap-05-recipient-management.png)

### 6. Add a recipient

The add-recipient dialog groups the name and email-address fields used to maintain report recipients. The record identifier and background data are concealed.

![Redacted add-recipient dialog](images/voc-hap-06-add-recipient.png)

### 7. Edit a recipient

The edit-recipient dialog supports maintaining existing recipient details. Its entered values and background records are concealed.

![Redacted edit-recipient dialog](images/voc-hap-07-edit-recipient.png)

### 8. Historical PDF review

The historical-report screen lets the user select a customer and date range and generate a PDF for review. The UI explicitly states that this action does not send customer emails or update email history. The screenshot's date values are concealed.

![Redacted historical PDF-report screen](images/voc-hap-08-historical-report.png)

### 9. Monthly reporting and email processing

The monthly-run confirmation screen describes generating a VOC/HAP PDF for each active customer and emailing it to assigned recipients. It also presents a test-email control. The reporting-period values are concealed.

![Redacted monthly email-run confirmation](images/voc-hap-09-monthly-email-run.png)

## Conceptual workflow

```text
Customer reporting setup + recipient assignments
                     |
             Reporting workflow
                /           \
Historical review        Monthly processing
Customer/date range      Active customers
PDF for review           Report generation + assigned recipients
No email sent            Customer email distribution
```

This is a conceptual workflow, not a production infrastructure topology. It does not specify the email transport, authentication mechanism, hosting environment, database schema, or job execution model.

## Engineering considerations

A specific hardest technical challenge has not been identified. Relevant considerations supported by the workflow include:

- Replacing the legacy reporting application's workflow in a maintainable desktop application.
- Organizing customer configuration and recipient assignments.
- Making reporting-period selection and run status understandable.
- Keeping historical report review distinct from customer email distribution.
- Giving users an explicit confirmation step before monthly processing.

These are design considerations, not invented accounts of particular incidents, architectural decisions, or solutions.

## Confirmed outcome

The application is a deployed replacement for the legacy VB.NET reporting application and is currently in use. The legacy application had Crystal Reports runtime issues.

No time savings, financial impact, reliability percentage, error reduction, production volume, or regulatory certification has been confirmed. A displayed run result is not used as a general performance statistic.

## Technology and remaining implementation details

The existing portfolio documents .NET 8, WPF, SQL Server, and QuestPDF for this project. Verify that this remains the current implementation stack before expanding technical claims. No email provider, API, scheduler, queue, authentication scheme, or runtime root cause has been supplied.

## Image provenance and publication

The images are AI-assisted redacted renders derived from Jason's supplied application screenshots. They may differ in typography, dimensions, or composition from the originals and must not be described as unchanged pixel-exact captures. They illustrate the supplied workflows and must not be used to infer undocumented implementation details. All original screenshots are excluded from this package.

See `IMAGE_REVIEW.md` for the image review. Employer permission to publish the application descriptions and edited images remains a separate consideration.
