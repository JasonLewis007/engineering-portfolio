# CODEX TASK — Build the VOC/HAP Reporting Modernization case study

Work in the existing `engineering-portfolio` React + TypeScript repository. Inspect the routing, shared project data, design system, shipping case study, screenshot gallery, and existing reporting entry before editing. Preserve unrelated work.

## Confirmed project facts

- Engineer: Jason Lewis.
- Role: Independent software engineer and application owner. Jason confirmed that he built this application independently.
- Status: Deployed and currently being used.
- Modernization: Replaced a legacy VB.NET application that was experiencing Crystal Reports runtime issues.
- Do not describe the application as merely planned or still in development.
- A specific hardest technical challenge has not been identified. Do not invent one. Use an “Engineering considerations” section for relevant design concerns without claiming an undocumented incident or solution.

The existing project entry lists .NET 8, WPF, SQL Server, and QuestPDF. Retain the documented stack and distinguish supplied facts from deductions; flag any library or implementation detail needing confirmation. Do not invent an email transport, API, service, authentication system, scheduler, queue, database schema, or infrastructure topology.

## Screenshot-supported workflow

The supplied interface captures show:

1. Main dashboard with a reporting period, last-run information, run results, and workflow entry points.
2. Customer management with customer report assignments, active status, consignment settings, and recipient counts.
3. Customer add/edit screens with recipient assignments.
4. Recipient management and add/edit screens.
5. Historical VOC/HAP PDF generation for a selected customer and date range. The UI explicitly distinguishes this review-only action from sending email or updating email history.
6. A monthly email-run confirmation screen describing report generation for active customers and delivery to assigned recipients, plus a test-email control.

Describe those interface workflows accurately. A control or status shown in a screenshot is not independent proof of a particular backend mechanism, delivery guarantee, production reliability rate, or implementation choice.

## Screenshot handling and confidentiality

This package includes nine AI-assisted redacted screenshot renders in `images/`. Read `IMAGE_REVIEW.md` and `image-manifest.json` before use. Original screenshots are deliberately excluded. The edited images have privacy masks and may differ in typography, dimensions, or composition from the source; they are not pixel-exact exports. Do not label them as untouched original screenshots.

Reinspect every image at full resolution for customer names and locations, email addresses, identifiers, branding, dates, counts, and any background text behind popup windows. If anything sensitive is still visible, withhold that image and report the issue. Never ship a sensitive image behind CSS blur or overlays. Use only reviewed local PNGs in `public/images/voc-hap/`, preserving each exported image's aspect ratio. Use the manifest's workflow captions and accurate alt text. Do not claim that redacted data or run results are visible.

The masks conceal customer/recipient fields, operational details, branding, and development overlays. Employer permission for public use remains a separate consideration; this package does not establish it.

## Page structure and content

Preserve the existing `/projects/reporting-modernization` route and GitHub Pages hash routing. Build a dedicated case study matching the portfolio's dark navy/blue design. Reuse components and keep content strongly typed.

Include:

- Hero: “VOC/HAP Reporting Modernization,” independent ownership, a deployed/in-use indicator, and documented technology badges.
- Overview: replacement of a VB.NET reporting application experiencing Crystal Reports runtime issues, and the purpose of customer reporting and distribution.
- Ownership: independent engineering ownership. Present the role clearly; do not invent specific architectural decisions, test strategies, deployment methods, or business outcomes.
- Legacy context: explain the known runtime problem without guessing its root cause, frequency, outage history, or exact resolution mechanism.
- Workflow sections: dashboard, customer setup, recipient management, historical PDF reports, and monthly report/email processing.
- Engineering considerations: maintainable reporting, customer/recipient associations, reporting-period selection, separating historical review from customer distribution, and communicating run status. Present these as considerations, not fabricated “hardest challenges.”
- Architecture: a conceptual diagram only where the documented components support it. Label it conceptual. Leave the email-delivery mechanism unspecified unless confirmed.
- Outcomes: a deployed replacement for the legacy VB.NET reporting application, currently in use. Do not invent time savings, financial savings, performance gains, error reductions, regulatory certification, or reliability statistics. Do not turn a screenshot's single-run count into a general performance claim.
- Technology stack and closing Projects/Contact links.

Remove superseded reporting-specific uncertainty about overall deployment and ownership. Do not make unsupported claims about every planned feature. Keep any remaining implementation questions in development documentation rather than misleading public claims.

## Portfolio integration

Update the reporting project summary and production status in the shared project data, so Home and Projects use the same description. Keep shipping as the flagship. Preserve the remaining case studies, résumé, portrait, Skills, Experience, and Contact pages.

Reuse the existing accessible screenshot viewer. Its current asset-path helper is shipping-specific; generalize it safely for trusted local case-study image paths without breaking the shipping gallery. Keep Escape dismissal, focus containment/restoration, previous/next buttons and arrow keys, descriptive alt text, captions, correct aspect ratios, responsive sizing, and reduced-motion behavior. Withheld screenshots must not open sensitive files or nonexistent assets.

## Validation and delivery

- Run `npm run build` and `npm run lint`; fix failures.
- Run existing relevant tests if available. Do not claim a nonexistent or unexecuted suite passed.
- Verify the reporting route, direct-link refreshes, Home/Projects links, shipping gallery, image loading, viewer keyboard behavior, and representative unrelated pages.
- Check desktop and mobile layouts, overflow, accessible names, contrast, and visible focus.
- Inspect exported public images and production output to ensure originals and sensitive values are absent.
- Preserve the static architecture and restrictive production CSP. Add no backend, credentials, analytics, trackers, external image hosting, or unnecessary dependencies.
- Report changed files, route, public image paths, redaction decisions, validation results, remaining factual questions, and exact preview commands.

Do not commit, push, deploy, publish, or change GitHub settings without explicit approval. Make the implementation reviewable locally first.
