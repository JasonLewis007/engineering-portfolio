# VOC/HAP case-study handoff

This package contains nine redacted image renders, case-study content, and a complete Codex implementation task.

## Use with Codex

1. Extract this ZIP outside your repository, or into a temporary ignored source directory.
2. Open the existing `engineering-portfolio` repository in Codex.
3. Provide this package and paste `CODEX_TASK.md` as the task.
4. Have Codex review `CASE_STUDY.md`, `IMAGE_REVIEW.md`, `image-manifest.json`, and all nine images before integration.
5. Review the local implementation before authorizing any commit, push, deployment, or publication.

The intended existing case-study route is `/projects/reporting-modernization`, using the portfolio's existing GitHub Pages hash routing. Keep the shipping case study as the flagship.

## Contents

- `CODEX_TASK.md`: full implementation instructions.
- `CASE_STUDY.md`: factual case-study draft and image references.
- `images/`: nine AI-assisted redacted PNGs.
- `image-manifest.json`: filenames, descriptions, alt text, dimensions, and checksums.
- `IMAGE_REVIEW.md`: redaction scope, provenance, and review results.

## Important image provenance

Privacy edits were made with an image-editing model, so these are edited screenshot renders, not pixel-exact original captures. Layout, typography, and dimensions may differ from the originals. No replacement customer records were requested. Use appropriate image captions and review the visuals before publication. The source originals and their ZIP are deliberately excluded.

## Content accuracy

Independent ownership, deployed/in-use status, and replacement of a VB.NET application with Crystal Reports runtime issues were confirmed by Jason. A “hardest challenge” and quantitative benefits were not supplied and have not been fabricated. The code-generation task uses an Engineering considerations section instead.

This handoff does not implement, commit, push, deploy, or publish any portfolio change. Employer permission for public use remains separate.
